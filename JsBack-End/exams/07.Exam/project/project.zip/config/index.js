module.exports = {
	PORT: 3000,
	DB_CONNECTION_STRING: "mongodb://localhost:27017/JobAdds",
	COOKIE_NAME: "SESSION",
	TOKEN_SECRET: "This is secure !",
};
