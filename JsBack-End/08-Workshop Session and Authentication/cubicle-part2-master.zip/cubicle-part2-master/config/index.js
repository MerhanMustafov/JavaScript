module.exports = {
    TOKEN_SECRET: 'my very secure secret',
    COOKIE_NAME: 'SESSION_DATA'
};