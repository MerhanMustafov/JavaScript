import { html, render} from './node_modules/lit-html/lit-html.js'
import {towns} from './towns.js'

export {html, render, towns}