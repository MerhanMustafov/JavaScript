const obj = {one: 1, two: 2}
console.log(obj)
obj['two'] = 5
console.log(obj)
obj['two'] = 2
console.log(obj)
obj['five'] = 5
console.log(obj)