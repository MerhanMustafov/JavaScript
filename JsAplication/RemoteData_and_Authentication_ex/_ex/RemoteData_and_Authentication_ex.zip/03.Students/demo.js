// let num = '1.5'
// if (!isNaN(num) && typeof num == 'string' && num.length > 0){
//     console.log(num)
// }