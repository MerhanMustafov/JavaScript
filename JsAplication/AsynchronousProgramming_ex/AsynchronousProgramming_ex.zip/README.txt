That below is my nickname on discord and my github account, you can find me there.

dicord >>> #Merho
github >>> https://github.com/MerhanMustafov

All feedbacks are appreciated, either negative or positive,
so feel free to write me if you want.


About the exercises:

3rd, 4th and 5th exercise are written entirely by me,
the other once are done after waching the solution of the theacher/lecturer
that is why you may find similarities in lecturer's and mine solutions.  

>>>>>> In some of the exercises i used modules(import and export) and changed some
things, just letting you know. <<<<<<<<<


P.S. 
In case you are wondering why i am writing in english, that is because otherwise
the Notepad is replacing the letters with question mark. And please ignore all the
mistake if you find any.