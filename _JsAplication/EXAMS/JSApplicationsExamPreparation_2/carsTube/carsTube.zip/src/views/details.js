import { html } from "../lib.js";
import { getCarById } from "../api/data.js";
import { getUserData } from "../api/utils.js";



const detailsTemplate = (car, isOwner) => html`
<section id="listing-details">
    <h1>Details</h1>
    <div class="details-info">
        <img src="${car.imageUrl}">
        <hr>
        <ul class="listing-props">
            <li><span>Brand:</span>${car.brand}</li>
            <li><span>Model:</span>${car.model}</li>
            <li><span>Year:</span>${car.year}</li>
            <li><span>Price:</span>${car.price}$</li>
        </ul>

        <p class="description-para">${car.description}</p>

        ${isOwner   ? html`<div class="listings-buttons">
                        <a href="/edit/${car._id}" class="button-list">Edit</a>
                        <a href="/delete/${car._id}" class="button-list">Delete</a>
                        </div>`
                    : null}
        
    </div>
</section>
`;


let ctx;
export async function detailsPage(context){
    ctx = context
    const userData = getUserData()
    const car = await getCarById(ctx.params.id)

    const isOwner = userData && userData.id == car._ownerId

    update()
    async function update(){
        // const comments = await getGameComments(ctx.params.id)
        ctx.render(detailsTemplate(car, isOwner))
    }

    async function addComment(e){
        e.preventDefault()
        let comment = document.querySelector('[name="comment"]')
        try{
            if(comment.value.trim() == ''){
                throw new Error ('you should add a comment')
            }
            const data = {comment: comment.value, gameId: ctx.params.id}
            postComment(data)
            
            comment.value = ''
            update()
        }catch (err) {{
            alert(err.message)
        }}

    }
}



